<?php
require __DIR__.'/config_db.php';
echo "OK: conectado a ".$conexion->host_info;
