<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: loggin.html");
    exit();
}

$conexion = new mysqli("localhost", "root", "", "loggin");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$fechadn = $_POST['fechadn'];
$correo = $_POST['correo'];  // correo no se modifica
$telefono = $_POST['telefono'];
$contrasena = $_POST['contrasena'];

$hash = password_hash($contrasena, PASSWORD_DEFAULT);

$sql = "UPDATE loggin SET nombre = ?, apellido = ?, fechadn = ?, numerotel = ?, contrasena = ? WHERE correo = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssssss", $nombre, $apellido, $fechadn, $telefono, $hash, $correo);

if ($stmt->execute()) {
    $_SESSION['usuario'] = $nombre;
    header("Location: mostrar.php");
    exit();
} else {
    echo "Error al actualizar: " . $stmt->error;
}

$stmt->close();
$conexion->close();
?>
