<?php
session_start();

// Redirigir si no hay sesión iniciada
if (!isset($_SESSION['usuario'])) {
    header("Location: loggin.html");
    exit();
}

$cliente = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Reserva de Vuelos</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #F5F0E6;
      color: #0A174E;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #F5F0E6;
      color: #0A174E;
      padding: 20px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 15px;
    }

    .logo {
      width: 50px;
      height: auto;
    }

    .menu {
      background-color: #333;
    }

    .menu button {
      background-color: #333;
      color: white;
      border: none;
      padding: 15px 20px;
      font-size: 18px;
      cursor: pointer;
      width: 100%;
      text-align: left;
    }

    .menu button:hover {
      background-color: #444;
    }

    .menu-items {
      display: none;
      flex-direction: column;
      background-color: #000;
    }

    .menu-items a {
      color: white;
      padding: 12px 20px;
      text-decoration: none;
    }

    .menu-items a:hover {
      background-color: #555;
    }

    .container {
      max-width: 900px;
      margin: 20px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      color: #0A174E;
    }

    label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }

    input, select {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    button[type="submit"] {
      margin-top: 15px;
      background-color: #0A174E;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    button[type="submit"]:hover {
      background-color: #08123b;
    }

    .tabla1 {
      width: 100%;
      border-collapse: collapse;
      border: 2px solid #333;
      margin: 20px 0;
    }

    .tabla1 td {
      border: 1px solid #999;
      text-align: center;
      vertical-align: middle;
      width: 20%;
    }

    .tabla1 img {
      max-width: 100%;
      height: auto;
      object-fit: contain;
    }

    footer {
      background-color: #1c3738;
      color: #F5F0E6;
      padding: 30px 20px;
      text-align: center;
    }

    footer a {
      color: #F5F0E6;
      text-decoration: none;
      margin-right: 15px;
    }
    .usuario {
  padding: 10px 20px;
  font-weight: bold;
  font-size: 16px;
}
    footer a:hover {
      text-decoration: underline;
    }

    @media (max-width: 600px) {
      .header-content {
        flex-direction: column;
        gap: 10px;
      }
    }

  </style>
</head>
<body>
<!---------------------------------->
<header>
  <div class="header-content">
    <img class="logo" src="Avion.jpg" alt="Logo Avión">
    <h1>Aerolínea Mexicana</h1>
    <p style="margin-left: auto;">Bienvenido, <?php echo htmlspecialchars($cliente); ?></p>
  </div>
</header>

<!---------------------------------->

  <div class="menu">
    <button onclick="toggleMenu()">☰ Menú</button>
    <div class="menu-items" id="menuItems">
      <a href="loggin.html">Iniciar Sesión</a>
      <a href="registro.html">Soy nuevo usuario</a>      
      <a href="ofertas.html">Ofertas Especiales</a>
      <a href="ayuda.html">Ayuda</a>
      <a href="logout.php">Cerrar Sesión</a>

    </div>
  </div>

  <div class="container">
    <h2>Buscar Vuelo</h2>
    <!---------------------------------->
<form action="mostrar.php" method="POST">
      <input type="hidden" name="cliente" value="<?php echo htmlspecialchars($cliente); ?>">
    <!---------------------------------->
  <label for="origen">Origen:</label>
      <select id="origen" name="origen" required>
        <option value="">Selecciona el estado donde te localizas</option>
    
        <option value="aguascalientes">Aguascalientes</option>
        <option value="baja_california">Baja California</option>
        <option value="baja_california_sur">Baja California Sur</option>
        <option value="campeche">Campeche</option>
        <option value="cdmx">Ciudad de México</option>
        <option value="coahuila">Coahuila</option>
        <option value="colima">Colima</option>
        <option value="chiapas">Chiapas</option>
        <option value="chihuahua">Chihuahua</option>
        <option value="durango">Durango</option>
        <option value="guanajuato">Guanajuato</option>
        <option value="guerrero">Guerrero</option>
        <option value="hidalgo">Hidalgo</option>
        <option value="jalisco">Jalisco</option>
        <option value="mexico">México</option>
        <option value="michoacan">Michoacán</option>
        <option value="morelos">Morelos</option>
        <option value="nayarit">Nayarit</option>
        <option value="nuevo_leon">Nuevo León</option>
        <option value="oaxaca">Oaxaca</option>
        <option value="puebla">Puebla</option>
        <option value="queretaro">Querétaro</option>
        <option value="quintana_roo">Quintana Roo</option>
        <option value="san_luis_potosi">San Luis Potosí</option>
        <option value="sinaloa">Sinaloa</option>
        <option value="sonora">Sonora</option>
        <option value="tabasco">Tabasco</option>
        <option value="tamaulipas">Tamaulipas</option>
        <option value="tlaxcala">Tlaxcala</option>
        <option value="veracruz">Veracruz</option>
        <option value="yucatan">Yucatán</option>
        <option value="zacatecas">Zacatecas</option>
      </select>
    
    <!---------------------------------->

      <label for="destino">Destino:</label>
      <select id="destino" name="destino" required>
        <option value="">Selecciona el estado donde deseas ir</option>
    
        <option value="aguascalientes">Aguascalientes</option>
        <option value="baja_california">Baja California</option>
        <option value="baja_california_sur">Baja California Sur</option>
        <option value="campeche">Campeche</option>
        <option value="cdmx">Ciudad de México</option>
        <option value="coahuila">Coahuila</option>
        <option value="colima">Colima</option>
        <option value="chiapas">Chiapas</option>
        <option value="chihuahua">Chihuahua</option>
        <option value="durango">Durango</option>
        <option value="guanajuato">Guanajuato</option>
        <option value="guerrero">Guerrero</option>
        <option value="hidalgo">Hidalgo</option>
        <option value="jalisco">Jalisco</option>
        <option value="mexico">México</option>
        <option value="michoacan">Michoacán</option>
        <option value="morelos">Morelos</option>
        <option value="nayarit">Nayarit</option>
        <option value="nuevo_leon">Nuevo León</option>
        <option value="oaxaca">Oaxaca</option>
        <option value="puebla">Puebla</option>
        <option value="queretaro">Querétaro</option>
        <option value="quintana_roo">Quintana Roo</option>
        <option value="san_luis_potosi">San Luis Potosí</option>
        <option value="sinaloa">Sinaloa</option>
        <option value="sonora">Sonora</option>
        <option value="tabasco">Tabasco</option>
        <option value="tamaulipas">Tamaulipas</option>
        <option value="tlaxcala">Tlaxcala</option>
        <option value="veracruz">Veracruz</option>
        <option value="yucatan">Yucatán</option>
        <option value="zacatecas">Zacatecas</option>
      </select>

    <!---------------------------------->

      <label for="fechas">Fecha de partida:</label>
      <input type="date" id="fecha1" name="fecha1" required>

      <button type="submit">Buscar</button>
    </form>
  </div>

  <table class="tabla1">
    <tr>
      <td><img src="im1.jpg" alt="Imagen 1"></td>
      <td><img src="im2.jpeg" alt="Imagen 2"></td>
      <td><img src="im3.jpeg" alt="Imagen 3"></td>
      <td><img src="im4.jpeg" alt="Imagen 4"></td>
      <td><img src="im5.jpeg" alt="Imagen 5"></td>
    </tr>
  </table>

  <footer>
    <h3>Contacto</h3>
    <p><strong>Email:</strong> contacto@aerolineamexicana.com</p>
    <p><strong>Teléfono:</strong> +52 55 1234 5678</p>
    <p><strong>Redes Sociales:</strong></p>
    <p>
      <a href="https://facebook.com/aerolineamexicana" target="_blank">Facebook</a>
      <a href="https://instagram.com/aerolineamexicana" target="_blank">Instagram</a>
      <a href="https://twitter.com/aerolineamx" target="_blank">Twitter</a>
    </p>
    <p style="margin-top: 20px;">© 2025 Aerolínea Mexicana. Todos los derechos reservados.</p>
  </footer>

  <script>
    function toggleMenu() {
      var menu = document.getElementById("menuItems");
      menu.style.display = (menu.style.display === "flex") ? "none" : "flex";
    }

    function redirigirLogin(event) {
      event.preventDefault(); // Detiene el envío del formulario
      window.location.href = "registro.html"; // Redirige a iniciar sesión
    }
  </script>

</body>
</html>
