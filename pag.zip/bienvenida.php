<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: loggin.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Bienvenido</title>
  <style>
    body {
      background-color: #F5F0E6;
      color: #0A174E;
      font-family: Arial, sans-serif;
      margin: 0;
    }

    header {
      background-color: white;
      padding: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .usuario {
      font-weight: bold;
    }

    a {
      text-decoration: none;
      color: #0A174E;
      font-weight: bold;
    }
  </style>
</head>
<body>

<header>
  <div class="usuario">Usuario: <?php echo htmlspecialchars($_SESSION['usuario']); ?></div>
  <div><a href="cerrar_sesion.php">Cerrar sesión</a></div>
</header>

<main style="padding: 20px;">
  <h1>Bienvenido a Aerolínea Mexicana</h1>
  <p>Gracias por iniciar sesión, <?php echo htmlspecialchars($_SESSION['usuario']); ?>.</p>
</main>

</body>
</html>