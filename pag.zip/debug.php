<?php
session_start();

echo "<h2>Debug de sesión</h2>";

if (isset($_SESSION['usuario'])) {
    echo "La sesión está activa. Usuario: <strong>" . htmlspecialchars($_SESSION['usuario']) . "</strong>";
} else {
    echo "❌ La sesión NO está activa.";
}
?>
