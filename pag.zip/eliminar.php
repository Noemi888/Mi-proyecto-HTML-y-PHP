<?php
session_start();

// Verificar sesión
if (!isset($_SESSION['usuario'])) {
    header("Location: loggin.html");
    exit();
}

// ✅ Conexión con InfinityFree
$host = "sqlXXX.epizy.com";
$usuarioBD = "epiz_XXXXXXX";
$contrasenaBD = "TU_CONTRASENA";
$baseDeDatos = "epiz_XXXXXXX_loggin";

$conexion = new mysqli($host, $usuarioBD, $contrasenaBD, $baseDeDatos);
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener correo
$correo = $_POST['correo'] ?? '';

if (empty($correo)) {
    echo "<script>alert('No se recibió el correo.'); window.location.href='mostrar.php';</script>";
    exit();
}

// Eliminar usuario
$sql = "DELETE FROM loggin WHERE correo = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $correo);

if ($stmt->execute()) {
    session_destroy();
    echo "<script>alert('Cuenta eliminada correctamente.'); window.location.href='registro.html';</script>";
} else {
    echo "<script>alert('Error al eliminar la cuenta.'); window.location.href='mostrar.php';</script>";
}

$stmt->close();
$conexion->close();
?>
