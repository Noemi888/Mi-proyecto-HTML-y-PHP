<?php
session_start();

// Verificar si hay sesión activa
if (!isset($_SESSION['usuario'])) {
    header("Location: loggin.html");
    exit();
}

// ✅ Conexión a InfinityFree — CAMBIA estos valores con los de tu cuenta:
$host = "sqlXXX.epizy.com";               // Ejemplo: sql313.epizy.com
$usuarioBD = "epiz_XXXXXXX";              // Tu usuario de MySQL
$contrasenaBD = "TU_CONTRASENA_AQUI";     // Tu contraseña de MySQL
$baseDeDatos = "epiz_XXXXXXX_loggin";     // Nombre de tu base de datos

$conexion = new mysqli($host, $usuarioBD, $contrasenaBD, $baseDeDatos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nombreSesion = $_SESSION['usuario'];

// Obtener datos del usuario actual desde la tabla
$sql = "SELECT * FROM loggin WHERE nombre = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $nombreSesion);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $usuario = $resultado->fetch_assoc();

    // Calcular edad
    $fechaNacimiento = new DateTime($usuario['fechadn']);
    $hoy = new DateTime();
    $edad = $fechaNacimiento->diff($hoy)->y;
} else {
    echo "Usuario no encontrado.";
    exit();
}

$stmt->close();
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Datos del Usuario</title>
    <style>
        body {
            background-color: #F5F0E6;
            color: #0A174E;
            font-family: Arial, sans-serif;
            padding: 40px;
            margin: 0;
        }

        header {
            background-color: #F5F0E6;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        .usuario-nombre {
            font-weight: bold;
            font-size: 18px;
        }

        .datos, .formulario-editar {
            max-width: 500px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .datos p {
            margin: 10px 0;
        }

        .botones {
            text-align: center;
        }

        .botones button {
            margin: 10px;
            padding: 10px 20px;
            background-color: #0A174E;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
        }

        .botones button:hover {
            background-color: #08123b;
        }

        input[type="text"], input[type="tel"] {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
    </style>
</head>
<body>

    <header>
        <h1>Aerolínea Mexicana</h1>
        <div class="usuario-nombre">Bienvenido, <?php echo htmlspecialchars($nombreSesion); ?></div>
    </header>

    <h2 style="text-align: center; margin-top: 40px;">Información de tu perfil</h2>

    <div class="datos">
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
        <p><strong>Apellido:</strong> <?php echo htmlspecialchars($usuario['apellido']); ?></p>
        <p><strong>Fecha de nacimiento:</strong> <?php echo htmlspecialchars($usuario['fechadn']); ?></p>
        <p><strong>Edad:</strong> <?php echo $edad; ?> años</p>
        <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($usuario['correo']); ?></p>
        <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($usuario['numerotel']); ?></p>
    </div>

    <div class="botones">
        <button onclick="document.getElementById('formEditar').style.display='block';">Modificar Datos</button>

        <form action="eliminar.php" method="post" onsubmit="return confirm('¿Estás seguro de eliminar tu cuenta? Esta acción no se puede deshacer.');" style="display: inline;">
            <input type="hidden" name="correo" value="<?php echo htmlspecialchars($usuario['correo']); ?>">
            <button type="submit">Eliminar Cuenta</button>
        </form>
    </div>

    <div class="formulario-editar" id="formEditar" style="display: none;">
        <h3>Editar Datos</h3>
        <form action="editar.php" method="post">
            <input type="hidden" name="correo" value="<?php echo htmlspecialchars($usuario['correo']); ?>">

            <label for="nombre">Nuevo Nombre:</label>
            <input type="text" name="nombre" value="<?php echo htmlspecialchars($usuario['nombre']); ?>" required>

            <label for="apellido">Nuevo Apellido:</label>
            <input type="text" name="apellido" value="<?php echo htmlspecialchars($usuario['apellido']); ?>" required>

            <label for="telefono">Nuevo Teléfono:</label>
            <input type="tel" name="telefono" value="<?php echo htmlspecialchars($usuario['numerotel']); ?>" required>

            <button type="submit">Guardar Cambios</button>
        </form>
    </div>

</body>
</html>
