<?php
session_start();

// ✅ Conexión con datos reales de InfinityFree
$host = "sqlXXX.epizy.com";            // Ejemplo: sql313.epizy.com
$usuario = "epiz_39478473";            // Tu usuario de MySQL
$contrasenaBD = "TuContraseñaAquí";    // Tu contraseña de MySQL
$basededatos = "epiz_39478473_loggin"; // Tu base de datos

$conexion = new mysqli($host, $usuario, $contrasenaBD, $basededatos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener datos del formulario
$correo = $_POST['correo'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$contrasena = $_POST['contrasena'] ?? '';

// Validar campos vacíos
if (empty($correo) || empty($telefono) || empty($contrasena)) {
    echo "<script>alert('Completa todos los campos'); window.location.href='loggin.html';</script>";
    exit();
}

// Buscar usuario por correo y teléfono
$sql = "SELECT * FROM loggin WHERE correo = ? AND numerotel = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ss", $correo, $telefono);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $fila = $resultado->fetch_assoc();

    // Verificar contraseña con hash
    if (password_verify($contrasena, $fila['contrasena'])) {
        $_SESSION['usuario'] = $fila['nombre']; // Puedes guardar más si quieres
        header("Location: aeropuerto.php");
        exit();
    } else {
        echo "<script>alert('Contraseña incorrecta'); window.location.href='loggin.html';</script>";
    }
} else {
    echo "<script>alert('Usuario no encontrado'); window.location.href='loggin.html';</script>";
}

$stmt->close();
$conexion->close();
?>
