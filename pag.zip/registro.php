<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// ✅ Cambia estos datos con los reales de tu panel de InfinityFree
$host = "sqlXXX.epizy.com";           // ← Cambia "sqlXXX" por el host real (ej. sql313.epizy.com)
$usuario = "epiz_39478473";           // ← Tu usuario de base de datos
$contrasena = "TuContraseñaAquí";     // ← Tu contraseña real
$baseDeDatos = "epiz_39478473_loggin"; // ← El nombre completo de tu base de datos

// Conexión
$conexion = new mysqli($host, $usuario, $contrasena, $baseDeDatos);
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Datos del formulario
$nombre = $_POST['nombre'] ?? '';
$apellido = $_POST['apellido'] ?? '';
$fechaNacimiento = $_POST['fechaNacimiento'] ?? '';
$correo = $_POST['correo'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$contrasena = $_POST['contrasena'] ?? '';

// Validación básica
if (empty($nombre) || empty($apellido) || empty($fechaNacimiento) || empty($correo) || empty($telefono) || empty($contrasena)) {
    echo "<script>alert('Por favor completa todos los campos.'); window.location.href='registro.html';</script>";
    exit();
}

// Validar que no se repita el correo o teléfono
$verificar = $conexion->prepare("SELECT id FROM loggin WHERE correo = ? OR numerotel = ?");
$verificar->bind_param("ss", $correo, $telefono);
$verificar->execute();
$verificar->store_result();

if ($verificar->num_rows > 0) {
    echo "<script>alert('Ya existe un usuario con este correo o teléfono.'); window.location.href='registro.html';</script>";
    $verificar->close();
    $conexion->close();
    exit();
}
$verificar->close();

// Encriptar contraseña
$hash = password_hash($contrasena, PASSWORD_DEFAULT);

// Insertar usuario
$sql = "INSERT INTO loggin (nombre, apellido, fechadn, correo, numerotel, contrasena)
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssssss", $nombre, $apellido, $fechaNacimiento, $correo, $telefono, $hash);

if ($stmt->execute()) {
    $_SESSION['usuario'] = $nombre;
    header("Location: aeropuerto.php");
    exit();
} else {
    echo "<script>alert('Error al registrar: " . $stmt->error . "'); window.location.href='registro.html';</script>";
}

$stmt->close();
$conexion->close();
?>
